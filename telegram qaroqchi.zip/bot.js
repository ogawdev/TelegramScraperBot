const bot = require("./index");

bot.launch(() => console.log("bot start"));
